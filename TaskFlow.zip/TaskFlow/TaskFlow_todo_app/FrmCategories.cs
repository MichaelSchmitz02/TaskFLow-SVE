﻿using ProjectRoy.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Fanya_todo_app.DataAccess.Models;
using ServiceStack.OrmLite;
using Kimtoo.BindingProvider;

namespace Fanya_todo_app
{
    public partial class FrmCategories : Form
    {
        public FrmCategories()
        {
            InitializeComponent();

            var db = DbContext.GetInstance();

            var data = db.Select<Category>();

            grid.OnEdit<Category>((r, c) => db.Save(r) || true);

            grid.OnDelete<Category>((r, c) => db.Delete(r) >= 0);

            grid.OnError<Category>((r, c) => bunifuSnackbar1.Show(this, DbContext.Exception.Message, Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error));

            grid.Bind(data);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var db = DbContext.GetInstance();

            var newCat = new Category();

            db.Save(newCat);

            grid.Bind(newCat, 0);
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (grid.CurrentRow.Tag == null) return;

            grid.DeleteRow<Category>();
        }
    }
}