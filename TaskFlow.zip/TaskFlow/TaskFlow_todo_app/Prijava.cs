﻿using Fanya_todo_app;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskFlow_todo_app
{
    public partial class Prijava : Form
    {
        private const string adminUsername = "admin";
        private const string adminPassword = "admin123";
        private const string userUsername = "user";
        private const string userPassword = "user123";

        public string UserRole { get; private set; }
        public Prijava()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuLabel1_Click(object sender, EventArgs e)
        {

        }

        private void btnPrijava_Click(object sender, EventArgs e)
        {
            string username = txtkrIme.Text;
            string password = txtLozinka.Text;


            if (username == adminUsername && password == adminPassword)
            {
                UserRole = "Admin";
                MessageBox.Show("Prijava uspješna kao Admin!", "Prijava", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else if (username == userUsername && password == userPassword)
            {
                UserRole = "User";
                MessageBox.Show("Prijava uspješna kao Korisnik!", "Prijava", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Neispravno korisničko ime ili lozinka.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
