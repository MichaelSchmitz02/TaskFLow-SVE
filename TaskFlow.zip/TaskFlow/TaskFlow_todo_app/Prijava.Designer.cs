﻿namespace TaskFlow_todo_app
{
    partial class Prijava
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Prijava));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtLozinka = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtkrIme = new Bunifu.UI.WinForms.BunifuTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnPrijava = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.AutoSize = false;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(127, 220);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(112, 21);
            this.bunifuLabel1.TabIndex = 8;
            this.bunifuLabel1.Text = "Korisniško Ime";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuLabel1.Click += new System.EventHandler(this.bunifuLabel1_Click);
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel2.Location = new System.Drawing.Point(127, 302);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(59, 21);
            this.bunifuLabel2.TabIndex = 9;
            this.bunifuLabel2.Text = "Lozinka";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtLozinka
            // 
            this.txtLozinka.AcceptsReturn = false;
            this.txtLozinka.AcceptsTab = false;
            this.txtLozinka.AnimationSpeed = 200;
            this.txtLozinka.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtLozinka.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtLozinka.AutoSizeHeight = true;
            this.txtLozinka.BackColor = System.Drawing.Color.Transparent;
            this.txtLozinka.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtLozinka.BackgroundImage")));
            this.txtLozinka.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtLozinka.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtLozinka.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtLozinka.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtLozinka.BorderRadius = 1;
            this.txtLozinka.BorderThickness = 1;
            this.txtLozinka.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtLozinka.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLozinka.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.txtLozinka.DefaultText = "";
            this.txtLozinka.FillColor = System.Drawing.Color.White;
            this.txtLozinka.HideSelection = true;
            this.txtLozinka.IconLeft = null;
            this.txtLozinka.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLozinka.IconPadding = 10;
            this.txtLozinka.IconRight = null;
            this.txtLozinka.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLozinka.Lines = new string[0];
            this.txtLozinka.Location = new System.Drawing.Point(127, 329);
            this.txtLozinka.MaxLength = 32767;
            this.txtLozinka.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtLozinka.Modified = false;
            this.txtLozinka.Multiline = false;
            this.txtLozinka.Name = "txtLozinka";
            stateProperties25.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLozinka.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtLozinka.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLozinka.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLozinka.OnIdleState = stateProperties28;
            this.txtLozinka.Padding = new System.Windows.Forms.Padding(3);
            this.txtLozinka.PasswordChar = '\0';
            this.txtLozinka.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtLozinka.PlaceholderText = "Enter text";
            this.txtLozinka.ReadOnly = false;
            this.txtLozinka.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLozinka.SelectedText = "";
            this.txtLozinka.SelectionLength = 0;
            this.txtLozinka.SelectionStart = 0;
            this.txtLozinka.ShortcutsEnabled = true;
            this.txtLozinka.Size = new System.Drawing.Size(260, 39);
            this.txtLozinka.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtLozinka.TabIndex = 7;
            this.txtLozinka.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtLozinka.TextMarginBottom = 0;
            this.txtLozinka.TextMarginLeft = 3;
            this.txtLozinka.TextMarginTop = 1;
            this.txtLozinka.TextPlaceholder = "Enter text";
            this.txtLozinka.UseSystemPasswordChar = false;
            this.txtLozinka.WordWrap = true;
            // 
            // txtkrIme
            // 
            this.txtkrIme.AcceptsReturn = false;
            this.txtkrIme.AcceptsTab = false;
            this.txtkrIme.AnimationSpeed = 200;
            this.txtkrIme.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtkrIme.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtkrIme.AutoSize = true;
            this.txtkrIme.AutoSizeHeight = true;
            this.txtkrIme.BackColor = System.Drawing.Color.Transparent;
            this.txtkrIme.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtkrIme.BackgroundImage")));
            this.txtkrIme.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtkrIme.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtkrIme.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtkrIme.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtkrIme.BorderRadius = 1;
            this.txtkrIme.BorderThickness = 1;
            this.txtkrIme.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtkrIme.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtkrIme.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.txtkrIme.DefaultText = "";
            this.txtkrIme.FillColor = System.Drawing.Color.White;
            this.txtkrIme.HideSelection = true;
            this.txtkrIme.IconLeft = null;
            this.txtkrIme.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtkrIme.IconPadding = 10;
            this.txtkrIme.IconRight = null;
            this.txtkrIme.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtkrIme.Lines = new string[0];
            this.txtkrIme.Location = new System.Drawing.Point(127, 247);
            this.txtkrIme.MaxLength = 32767;
            this.txtkrIme.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtkrIme.Modified = false;
            this.txtkrIme.Multiline = false;
            this.txtkrIme.Name = "txtkrIme";
            stateProperties29.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Empty;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtkrIme.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtkrIme.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties31.FillColor = System.Drawing.Color.Empty;
            stateProperties31.ForeColor = System.Drawing.Color.Empty;
            stateProperties31.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtkrIme.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.Silver;
            stateProperties32.FillColor = System.Drawing.Color.White;
            stateProperties32.ForeColor = System.Drawing.Color.Empty;
            stateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtkrIme.OnIdleState = stateProperties32;
            this.txtkrIme.Padding = new System.Windows.Forms.Padding(3);
            this.txtkrIme.PasswordChar = '\0';
            this.txtkrIme.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtkrIme.PlaceholderText = "Enter text";
            this.txtkrIme.ReadOnly = false;
            this.txtkrIme.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtkrIme.SelectedText = "";
            this.txtkrIme.SelectionLength = 0;
            this.txtkrIme.SelectionStart = 0;
            this.txtkrIme.ShortcutsEnabled = true;
            this.txtkrIme.Size = new System.Drawing.Size(260, 39);
            this.txtkrIme.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtkrIme.TabIndex = 6;
            this.txtkrIme.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtkrIme.TextMarginBottom = 0;
            this.txtkrIme.TextMarginLeft = 3;
            this.txtkrIme.TextMarginTop = 1;
            this.txtkrIme.TextPlaceholder = "Enter text";
            this.txtkrIme.UseSystemPasswordChar = false;
            this.txtkrIme.WordWrap = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TaskFlow_todo_app.Properties.Resources.TaskFlow__2_;
            this.pictureBox1.Location = new System.Drawing.Point(152, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(207, 190);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnPrijava
            // 
            this.btnPrijava.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrijava.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(163)))));
            this.btnPrijava.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(163)))));
            this.btnPrijava.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrijava.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrijava.ForeColor = System.Drawing.Color.White;
            this.btnPrijava.Location = new System.Drawing.Point(184, 394);
            this.btnPrijava.Name = "btnPrijava";
            this.btnPrijava.Size = new System.Drawing.Size(151, 36);
            this.btnPrijava.TabIndex = 10;
            this.btnPrijava.Text = "Prijava";
            this.btnPrijava.UseVisualStyleBackColor = false;
            this.btnPrijava.Click += new System.EventHandler(this.btnPrijava_Click);
            // 
            // btnExit
            // 
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(130)))), ((int)(((byte)(163)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(184, 445);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(151, 39);
            this.btnExit.TabIndex = 13;
            this.btnExit.Text = "Natrag";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Prijava
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(14)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(519, 516);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnPrijava);
            this.Controls.Add(this.bunifuLabel2);
            this.Controls.Add(this.bunifuLabel1);
            this.Controls.Add(this.txtLozinka);
            this.Controls.Add(this.txtkrIme);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Prijava";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prijava";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.UI.WinForms.BunifuTextBox txtkrIme;
        private Bunifu.UI.WinForms.BunifuTextBox txtLozinka;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private System.Windows.Forms.Button btnPrijava;
        private System.Windows.Forms.Button btnExit;
    }
}